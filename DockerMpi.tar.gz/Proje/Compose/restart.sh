docker-compose stop mpi_head
yes | docker-compose rm -v mpi_head
docker-compose up -d

